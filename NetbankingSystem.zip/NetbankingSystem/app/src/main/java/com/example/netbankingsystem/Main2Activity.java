package com.example.netbankingsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Main2Activity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener, RadioGroup.OnCheckedChangeListener {
    Spinner sp;
    TextView name;
    EditText AccountNo,price;
    Button btnpay,btnsaving,btncredit,signout;
    RadioGroup rg1;
    RadioButton rbsaving,rbcredit,rb;
     int savingBalance;
     int creditBalance;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);



        sp = findViewById(R.id.spinner);
        btnpay = findViewById(R.id.btnPay);
        rg1 = findViewById(R.id.rg1);
        name = findViewById(R.id.name);
        price = findViewById(R.id.price);
        AccountNo = findViewById(R.id.AccountNo);

        rbsaving = findViewById(R.id.rbsaving);
        rbcredit = findViewById(R.id.rbcredit);

        btnsaving = findViewById(R.id.btnsaving);
        btncredit = findViewById(R.id.btncredit);
        signout = findViewById(R.id.signout);

        savingBalance = getIntent().getIntExtra("savingBalance",0);//.toString());
        creditBalance = getIntent().getIntExtra("creditBalance",0);//.toString());
        Customer cust =  getIntent().getParcelableExtra("custObj");

     //   Toast.makeText(getApplicationContext(), "asasas and Credit : "+cust.getName(),Toast.LENGTH_SHORT).show();

//        Toast.makeText(getApplicationContext(), "Saving and Credit : "+savingBalance+" : "+creditBalance, Toast.LENGTH_LONG).show();


        name.setText(MainActivity.customerName);



        List<String> bill = new ArrayList<>();

        bill.add("Hydro Bill");
        bill.add("Phone Bill");
        bill.add("Gas Bill");
        bill.add("Water Bill");

        ArrayAdapter<String> cauAdaptor = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, bill);
        cauAdaptor.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        sp.setAdapter(cauAdaptor);

        sp.setOnItemSelectedListener(this);
        btnpay.setOnClickListener(this);
        btnsaving.setOnClickListener(this);
        btncredit.setOnClickListener(this);
        signout.setOnClickListener(this);
        rg1.setOnCheckedChangeListener(this);




    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

//        String item;
//        item = parent.getItemAtPosition(position).toString();
//
//
//        i = position;
//        Integer p = new Integer(value[i]);

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.btnsaving:
                Intent go = new Intent(this, Main3Activity.class);

                go.putExtra("savingBalance",savingBalance);
                go.putExtra("creditBalance",creditBalance);

                startActivity(go);
                break;

            case R.id.btncredit:
                Intent go2 = new Intent(this, Main3Activity.class);

                go2.putExtra("savingBalance",savingBalance);
                go2.putExtra("creditBalance",creditBalance);

                startActivity(go2);
                break;

            case R.id.signout:
                Intent go3 = new Intent(this, MainActivity.class);
                startActivity(go3);
                break;

            case R.id.btnPay:


                Spinner mySpinner = (Spinner) findViewById(R.id.spinner);
                String t = mySpinner.getSelectedItem().toString();

                int radioSelected = rg1.getCheckedRadioButtonId();
//                Toast.makeText(getApplicationContext(), "Selected Radio : " + radioSelected, Toast.LENGTH_LONG).show();
                rb = findViewById(radioSelected);
                int f = 0;

                Log.d("Sukh","Radio : "+radioSelected);


                int s = savingBalance;
                int c = creditBalance;


                if(rb.getText().toString().equalsIgnoreCase("Saving")){

                    if(AccountNo.getText().toString().equalsIgnoreCase("")){
                        Toast.makeText(getApplicationContext(),"Enter Account Number",Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if(price.getText().toString().equalsIgnoreCase("")){
                        Toast.makeText(getApplicationContext(),"Please Enter Amount",Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int q = Integer.parseInt(price.getText().toString());
                    if(s < q){
                        Toast.makeText(getApplicationContext(), "You dont have Sufficient Balance to Pay  " +t.toString(), Toast.LENGTH_LONG).show();
                    }
                    else {
                        f = s - q;
                        savingBalance = f;

                        Toast.makeText(getApplicationContext(),  t.toString() + " -- has been Paid " , Toast.LENGTH_LONG).show();
                    }

                }
                else{
                    int q = Integer.parseInt(price.getText().toString());
                    if(c < q){
                        Toast.makeText(getApplicationContext(), "You dont have Sufficient Balance to Pay  "+t.toString() , Toast.LENGTH_LONG).show();
                    }else {
                        f = c - q;
                        creditBalance = f;

                        Toast.makeText(getApplicationContext(),  t.toString() + " -- has been Paid " , Toast.LENGTH_LONG).show();
                    }

                }




                break;
        }


    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int id) {



    }
}
