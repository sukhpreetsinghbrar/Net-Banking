package com.example.netbankingsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    public static Customer cust[] = new Customer[4];
    EditText etUserName, etPassword;
    Button login;
    public static String customerName;
    public static int custIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUserName = findViewById(R.id.etUserName);
        etPassword = findViewById(R.id.etPassword);
        login = findViewById(R.id.btLogin);
        login.setOnClickListener(this);

        cust[0]= new Customer(11,"Sukhpreet Singh Brar","user1","1111",2000,1000);
        cust[1]= new Customer(22,"   Ramanpreet Kaur  ","user2","2222",5000 ,2500);
        cust[2]= new Customer(33,"  Supriya Sachdeva  ","user3","3333",10000,20000);
        cust[3]= new Customer(44,"      Parmjeet Kaur     ","user4","4444",1000,500);

    }

    @Override
    public void onClick(View v)
    {
        String userEntry = etUserName.getText().toString();
        String passEntry = etPassword.getText().toString();
        int custId = searchUser(cust,userEntry,passEntry);
        if(custId==-1)
            Toast.makeText(getApplicationContext(),"Invalid username or password",Toast.LENGTH_LONG).show();
        else{
            int i=findCustomerById(cust,custId);
            custIndex=i;
            customerName=cust[i].getName();
            Intent go = new Intent(this, Main2Activity.class);
            go.putExtra("savingBalance",cust[i].getSavingB());
            go.putExtra("creditBalance",cust[i].getCreditB());
            go.putExtra("custObj", cust[i]);
            startActivity(go);
        }
    }
    public static int searchUser(Customer cust[],String user, String pass)
    {
        int id;
        for (int i =0;i<cust.length;i++)
            if(user.equals(cust[i].getUsername()) && pass.equals(cust[i].getPassword()))
            {id=cust[i].getId();
                return id;}
        return -1;


    }
    public static int findCustomerById(Customer cust[],int custId)
    {
        for(int i=0;i<cust.length;i++)
            if(cust[i].getId()==custId)
                return i;
        return -1;
    }
}
