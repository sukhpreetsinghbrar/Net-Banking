package com.example.netbankingsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity implements View.OnClickListener, RadioGroup.OnCheckedChangeListener {

    TextView etSaving, etCredit;
    EditText payCredit, name,email,BankId,amount;
    Button send, back, pay;
    RadioGroup rg;
    RadioButton rb;
     int savingBalance;
     int creditBalance;
//    RadioButton rbsaving, rbcredit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        etSaving = findViewById(R.id.etSaving);
        etCredit = findViewById(R.id.etCredit);
        payCredit = findViewById(R.id.payCredit);
        amount = findViewById(R.id.amount);
        email = findViewById(R.id.email);
        BankId = findViewById(R.id.BankId);
        pay = findViewById(R.id.pay);
        back = findViewById(R.id.back);
        name = findViewById(R.id.name);
        rg = findViewById(R.id.rg);

        savingBalance = getIntent().getIntExtra("savingBalance",0);
        creditBalance = getIntent().getIntExtra("creditBalance",0);


        send = findViewById(R.id.send);

        etSaving.setText("" + savingBalance);
        etCredit.setText("" + creditBalance);

        send.setOnClickListener(this);
        back.setOnClickListener(this);
        pay.setOnClickListener(this);
        rg.setOnCheckedChangeListener(this);



    }

    @Override
    public void onBackPressed() {
//        Intent data = new Intent();
//        // add data to Intent
//
//        data.putExtra("savingBalance",savingBalance);
//        data.putExtra("creditBalance",creditBalance);
//        setResult(Main2Activity.RESULT_OK, data);
        Intent go4 = new Intent(this, Main2Activity.class);
        go4.putExtra("savingBalance",savingBalance);
        go4.putExtra("creditBalance",creditBalance);
        startActivity(go4);

        super.onBackPressed();
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.back:
                Intent go4 = new Intent(this, Main2Activity.class);
                go4.putExtra("savingBalance",savingBalance);
                go4.putExtra("creditBalance",creditBalance);
                startActivity(go4);

                break;

            case R.id.pay:
                int pp = 0;
                int fp = 0;

                if(payCredit.getText().toString().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Please Enter Amount",Toast.LENGTH_SHORT).show();
                    return;
                }
                int ss = Integer.parseInt(etSaving.getText().toString());
                int cc = Integer.parseInt(etCredit.getText().toString());
                int p = Integer.parseInt(payCredit.getText().toString());
                if(ss < p){
                    Toast.makeText(getApplicationContext(), "You dont have Sufficient Balance to Pay Credit" , Toast.LENGTH_LONG).show();
                 }
                else {
                    pp = ss - p;
                    fp = cc + p;

                    etSaving.setText("" + pp);
                    etCredit.setText("" + fp);
                    savingBalance = pp;
                    creditBalance = fp;
                    Toast.makeText(getApplicationContext(), "Credit has been Paid ", Toast.LENGTH_LONG).show();
                }
                break;

            case R.id.send:

                int radioSelected = rg.getCheckedRadioButtonId();
//                Toast.makeText(getApplicationContext(), "Selected Radio : " + radioSelected, Toast.LENGTH_LONG).show();
                rb = findViewById(radioSelected);
                int f = 0;

                Log.d("Sukh","Radio : "+radioSelected);




                if(rb.getText().toString().equalsIgnoreCase("Saving")){

                    if(name.getText().toString().equalsIgnoreCase("")){
                        Toast.makeText(getApplicationContext(),"Please Enter Reciver Name",Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if(email.getText().toString().equalsIgnoreCase("")){
                        Toast.makeText(getApplicationContext(),"Please Enter Reciver Email",Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if(BankId.getText().toString().equalsIgnoreCase("")){
                        Toast.makeText(getApplicationContext(),"Please Enter Account no",Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if(amount.getText().toString().equalsIgnoreCase("")){
                            Toast.makeText(getApplicationContext(),"Please Enter Amount",Toast.LENGTH_SHORT).show();
                            return;
                    }

                    int s = Integer.parseInt(etSaving.getText().toString());
                    int q = Integer.parseInt(amount.getText().toString());
                    if(s < q){
                        Toast.makeText(getApplicationContext(), "You dont have Sufficient Fund" , Toast.LENGTH_LONG).show();
                    }
                    else {



                        f = s - q;
                        etSaving.setText("" + f);
                        savingBalance = f;

                        String g = name.getText().toString();
                        String e = email.getText().toString();

                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("message/rfc822");
                        i.putExtra(Intent.EXTRA_EMAIL  , new String[]{""+e});
                        i.putExtra(Intent.EXTRA_SUBJECT, "Money Transfer");
                        i.putExtra(Intent.EXTRA_TEXT   , "You have recivied "+ q + " Dollars");
                        try {
                            startActivity(Intent.createChooser(i, "Send mail..."));
                        } catch (android.content.ActivityNotFoundException ex) {
                            Toast.makeText(Main3Activity.this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
                        }


                        Toast.makeText(getApplicationContext(), "Fund has been Send Sucessfully to -- " + g, Toast.LENGTH_LONG).show();
                    }
                }
                else{



                    if(name.getText().toString().equalsIgnoreCase("")){
                        Toast.makeText(getApplicationContext(),"Please Enter Reciver Name",Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if(email.getText().toString().equalsIgnoreCase("")){
                        Toast.makeText(getApplicationContext(),"Please Enter Reciver Email",Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if(BankId.getText().toString().equalsIgnoreCase("")){
                        Toast.makeText(getApplicationContext(),"Please Enter Account no",Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if(amount.getText().toString().equalsIgnoreCase("")){
                        Toast.makeText(getApplicationContext(),"Please Enter Amount",Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int c = Integer.parseInt(etCredit.getText().toString());
                    int q = Integer.parseInt(amount.getText().toString());
                    if( c < q){
                        Toast.makeText(getApplicationContext(), "You dont have Sufficient Fund" , Toast.LENGTH_LONG).show();
                    }
                    else {
                        f = c - q;
                        etCredit.setText("" + f);
                        creditBalance = f;

                        String g = name.getText().toString();
                        String e = email.getText().toString();

                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("message/rfc822");
                        i.putExtra(Intent.EXTRA_EMAIL  , new String[]{""+e});
                        i.putExtra(Intent.EXTRA_SUBJECT, "Money Transfer");
                        i.putExtra(Intent.EXTRA_TEXT   , "You have recivied "+ q + " Dollars");
                        try {
                            startActivity(Intent.createChooser(i, "Send mail..."));
                        } catch (android.content.ActivityNotFoundException ex) {
                            Toast.makeText(Main3Activity.this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
                        }


                        Toast.makeText(getApplicationContext(), "Fund has been Send Sucessfully to -- " + g, Toast.LENGTH_LONG).show();

                    }
                }




                break;





        }





    }

    @Override
    public void onCheckedChanged(RadioGroup rg, int id) {



    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
