package com.example.netbankingsystem;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.List;

public class Customer implements Parcelable {
    private int id;
    private String name;
    private String username;
    private String password;
    public int savingB;
    public int creditB;
    private List<Integer> prodNo = new ArrayList<Integer>();

    public Customer(int id, String name, String username, String password,int sb, int cb) {
        this.id = id;
        this.name = name;
        this.username = username;
        this.password = password;
        this.savingB = sb;
        this.creditB = cb;

    }

    protected Customer(Parcel in) {
        id = in.readInt();
        name = in.readString();
        username = in.readString();
        password = in.readString();
        savingB = in.readInt();
        creditB = in.readInt();
    }

    public static final Creator<Customer> CREATOR = new Creator<Customer>() {
        @Override
        public Customer createFromParcel(Parcel in) {
            return new Customer(in);
        }

        @Override
        public Customer[] newArray(int size) {
            return new Customer[size];
        }
    };

    public void addPurchasedProduct(int prodNo) {
        this.prodNo.add(prodNo);
    }

    public int getId() {
        return id;
    }
    public String getName() {return name;}
    public String getUsername(){return username;}
    public String getPassword(){return password;}
    public int getSavingB() {return savingB;}
    public int getCreditB() {return creditB;}
    public List<Integer> getPurchasedProducts(){
        return prodNo;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(id);
        parcel.writeString(name);
        parcel.writeString(username);
        parcel.writeString(password);
        parcel.writeInt(savingB);
        parcel.writeInt(creditB);
    }
}